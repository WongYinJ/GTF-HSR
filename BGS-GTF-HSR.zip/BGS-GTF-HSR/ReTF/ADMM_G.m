function [G] = ADMM_G(Tx,Ty,G,U,Uaux,P,GLS,rho,ksi,InLoop)
%ADMM_G �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
R=size(P,1);
K=size(GLS,2);
[r1,r2,r3]=size(G);
if R==1
    Graux=double(ttm(tensor(Ty),{U{1}',U{2}',(P{1,3}*Uaux{3})'}))+...
            double(ttm(tensor(Tx),{(P{1,1}*Uaux{1})',(P{1,2}*Uaux{2})',U{3}'}));
    for k=1:K
        Graux=Graux+rho(2)/rho(1)*GLS{2,k};%GLS{2,k};
    end
     [Q1,Sig1,~]=svd((P{1,1}*Uaux{1})'*(P{1,1}*Uaux{1}));
     [Q2,Sig2,~]=svd((P{1,2}*Uaux{2})'*(P{1,2}*Uaux{2}));
     [Q3,Sig3,~]=svd((P{1,3}*Uaux{3})'*(P{1,3}*Uaux{3}));
     Graux=double(ttm(tensor(Graux),{Q1,Q2,Q3}));
     %%%%%%%%%%%%%%%%%%%%%  
     Graux=Graux./(rho(2)/rho(1)*K*ones(r1,r2,r3)+double(ktensor({ones(r1,1),ones(r2,1),diag(Sig3)}))+...
                double(ktensor({diag(Sig1),diag(Sig2),ones(r3,1)})));%%%%%%%%%%%%%%%%%%%%
     G=double(ttm(tensor(Graux),{Q1',Q2',Q3'}));
else
    Gr=cell(1,R);Hr=cell(1,R);
    for r=1:R
        Gr{r}=G;Hr{r}=zeros(size(G));
    end
    for loop=1:InLoop
        %Gr
        for r=1:R
            Txaux=Tx;
            for r_=1:R
                if r_~=r
                    Txaux=Txaux-double(ttm(tensor(Gr{r_}),{P{r_,1}*Uaux{1},P{r_,2}*Uaux{2},U{3}}));
                end
            end
            Graux=ksi/rho(1)*(G+Hr{r}/ksi)+double(ttm(tensor(Ty),{U{1}',U{2}',(P{1,3}*Uaux{3})'}))/R+...
                double(ttm(tensor(Txaux),{(P{r,1}*Uaux{1})',(P{r,2}*Uaux{2})',U{3}'}));
            [Q1,Sig1,~]=svd((P{r,1}*Uaux{1})'*(P{r,1}*Uaux{1}));
            [Q2,Sig2,~]=svd((P{r,2}*Uaux{2})'*(P{r,2}*Uaux{2}));
            [Q3,Sig3,~]=svd((P{r,3}*Uaux{3})'*(P{r,3}*Uaux{3}));
            Graux=double(tensor(Graux),{Q1,Q2,Q3});
            Graux=Graux./(ksi/rho(1)*ones(r1,r2,r3)+double(ktensor({ones(r1,1),ones(r2,1),diag(Sig3)}))/R+...
                double(ktensor({diag(Sig1),diag(Sig2),ones(r3,1)})));
            Gr{r}=double(tensor(Graux),{Q1',Q2',Q3'});
        end
        %G
        Graux=0;
        for k=1:K
            Graux=Graux+rho(2)*GLS{2,k};%GLS{2,k};
        end
        for r=1:R
            Graux=Graux+ksi*(Gr{r}-Hr{r}/ksi);
        end
% % % % % %         G=Graux/(2*K+R);
        G=Graux/(K*rho(2)+R*(ksi));
        %Hr
        for r=1:R
            Hr{r}=Hr{r}+ksi*(G-Gr{r});
        end
    end
end
end

