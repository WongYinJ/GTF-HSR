function [Unew] = ADMM_U(Tx,Ty,G,U,P,psi,ULoop,i)
%ADMM_U �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
Uaux=U{i};
Fu=zeros(size(Uaux));
R=size(P,1);
nu=1.2;
if i==3
    for loop=1:ULoop
        %Uaux
        [E,F,B,Tau] = CreateCGSys(Ty,G,U,U,P,U{i}+Fu/psi,psi,i);
        Uaux = CGra(E,F,Tau,Uaux,B);
        %U
        Raux=0;
        for r=1:R
            Raux=Raux+double(ttm(tensor(G),{P{r,1}*U{1},P{r,2}*U{2}},[1,2]));
        end
        [J,~,Q]=svd(Unfold(Raux,i)*Unfold(Tx,i)'+psi/2*(Uaux-Fu/psi)');
        U{i}=Q(:,1:size(U{i},2))*J';
        %Lagrarian
        Fu=Fu+psi*(U{i}-Uaux);
    end
else
    for loop=1:ULoop
         %Uaux
         [E,F,B,Tau] = CreateCGSys(Tx,G,U,U,P,U{i}+Fu/psi,psi,i);
         Uaux = CGra(E,F,Tau,Uaux,B);
         %U
         [J,~,Q]=svd(Unfold(double(ttm(tensor(G),{U{3-i},P{1,3}*U{3}},[3-i,3])),i) ...
         *Unfold(Ty,i)'+psi/2*(Uaux-Fu/psi)');
         U{i}=Q(:,1:size(U{i},2))*J';
        %Lagrarian
        Fu=Fu+psi*(U{i}-Uaux);
        psi=psi*nu;
% % % %         norm(U{i}-Uaux,'fro')/norm(U{i},'fro')
    end
    
end
Unew=U{i};
end

