function [E,F,B,Tau] = CreateCGSys(T,G,U,Uaux,P,W,psi,i)
%CREATECGSYS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
R=size(P,1);
B=0;
if i==3
    E=cell(1,2);F=cell(1,2);
    Gr=Unfold(double(ttm(tensor(G),{U{1},U{2}},[1,2])),i);
    B=P{1,3}'*Unfold(T,3)*Gr'+psi/2*W;
    E{1}=P{1,3}'*P{1,3};F{1}=Gr*Gr';
    E{end}=eye(size(Uaux{3},1));F{end}=eye(size(Uaux{3},2));
    Tau=[1,psi/2];
else
    Gr=cell(1,R);
    for r=1:R
        Gr{r}=Unfold(double(ttm(tensor(G),{P{r,3-i}*Uaux{3-i},U{3}},[3-i,3])),i);
        B=B+P{r,i}'*Unfold(T,i)*Gr{r}';
    end
    B=B+psi/2*W;
    E=cell(1,R^2+1);F=cell(1,R^2+1);
    k=1;
    for r1=1:R
        for r2=1:R
            E{k}=P{r1,i}'*P{r2,i};F{k}=Gr{r2}*Gr{r1}';
            k=k+1;
        end
    end
    E{end}=eye(size(Uaux{i},1));F{end}=eye(size(Uaux{i},2));
    Tau=ones(1,k);Tau(end)=psi/2;
end
end

