function [G] = GIni(SRI,X,Y,P,U,eta,phi,rho,alpha,beta,ksi,turank,shape_re,ss,IniLoop,InLoop)
%ADMM_GINI �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
R=size(P,1);
K=length(shape_re);
Px=zeros(size(X));Py=zeros(size(Y));
G=zeros(turank);
LS=cell(2,K);
MN=cell(2,K);
for k=1:K
    LS{1,k}=CirUnfold(reshape(G,shape_re),k,ss);LS{2,k}=CirUnfold(reshape(G,shape_re),k,ss);
    MN{1,k}=zeros(size(LS{1,k}));MN{2,k}=zeros(size(LS{2,k}));
end
GLS=cell(2,K);

rhomax=1e10;nu=1.013;%%%%nu=1.015;
ps=[];
error=[];
for loop=1:IniLoop
    Xpre=double(ttm(tensor(G),U));
    %%Update G
    disp('Update G')
    Gpre=G;
    for k=1:K
        GLS{1,k}=reshape(CirFold(LS{1,k}-MN{1,k}/rho(2),k,ss,shape_re),turank);
        GLS{2,k}=reshape(CirFold(LS{2,k}-MN{2,k}/rho(2),k,ss,shape_re),turank);
    end
    G = ADMM_G(X+Px/rho(1),Y+Py/rho(1),G,U,U,P,GLS,rho,ksi,InLoop);
    
    
    %%Update L,S
    disp('Update L,S')
    for k=1:K
        %L
% % % % % %         disp('Update L')
% % % % % %         [J,Sig,Q]=svd(CirUnfold(reshape(G,shape_re),k,ss)+MN{1,k}/rho(2));
% % % % % %         Sig_=LapSparse(Sig,eta*alpha(k)/rho(2),1e0,1e-7);
% % % % % %         LS{1,k}=J*Sig_*Q';
        %S
        disp('Update S')
        LS{2,k}=LapSparse(CirUnfold(reshape(G,shape_re),k,ss)+MN{2,k}/rho(2),phi*beta(k)/rho(2),1e1,1e-7);
    end
    %Update Lagrarian Variables
    disp('Update Lagrarian Variables')
    HSIes=0;
    for r=1:R
        HSIes=HSIes+double(ttm(tensor(G),{P{r,1}*U{1},P{r,2}*U{2},U{3}}));
    end
    Px=Px+rho(1)*(X-HSIes);
    Py=Py+rho(1)*(Y-double(ttm(tensor(G),{U{1},U{2},P{1,3}*U{3}})));
    for k=1:K
% % % % % %         MN{1,k}=MN{1,k}+rho(2)*(CirUnfold(reshape(G,shape_re),k,ss)-LS{1,k});
        MN{2,k}=MN{2,k}+rho(2)*(CirUnfold(reshape(G,shape_re),k,ss)-LS{2,k});
    end
    %Update rho
    rho=min(rhomax,nu*rho);
    %Stride
    bK=cell(1,K);
    for k=1:K
        b{k}=norm(CirUnfold(reshape(G,shape_re),k,ss)-LS{2,k},'fro')/norm(CirUnfold(reshape(G,shape_re),k,ss),'fro')
    end
    St1=norm(Unfold(G-Gpre,2),'fro')/norm(Unfold(G,2),'fro')
    b1=norm(Unfold(X-FormHSI({G},U,U,P),2),'fro')/norm(Unfold(X,2),'fro')
    b2=norm(Unfold(Y-double(ttm(tensor(G),{U{1},U{2},P{1,3}*U{3}})),2),'fro')/norm(Unfold(Y,2),'fro')
    ps=[ps;psnr(double(ttm(tensor(G),U)),SRI)];
    error=[error;norm(Unfold(Xpre-double(ttm(tensor(G),U)),2),'fro')/norm(Unfold(double(ttm(tensor(G),U)),2),'fro')];
end
plot(ps)
figure();
plot(error)
end

