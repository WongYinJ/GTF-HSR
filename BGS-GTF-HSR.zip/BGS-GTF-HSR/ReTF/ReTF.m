function [Z,ob] = ReTF(SRI,X,Y,P,eta,phi,rho,alpha,beta,ksi,turank,shape_re,ss,IniLoop,MaxLoop,InLoop)
%RETF �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% X:HSI; Y: MSI; P:R��3 cell containing degradation matrices
% eta: low-rank parameter; phi: sparse parameter; rho: optimization penalty
% ss: size of the second dimension in (k,ss)-unfolding
%%%Preparation
[m,n,S]=size(X);[M,N,s]=size(Y);
ratio=M/m;
R=size(P,1);
K=length(shape_re);

% % Gu=tucker_als(tensor(imresize(X,ratio)),turank);
% % G=double(Gu.core);
% % U=Gu.U';Uaux=Gu.U';
% % psnr(double(ttm(tensor(G),U)),SRI)
U=cell(1,3);
[U{1},~,~]=svds(Unfold(Y,1)*Unfold(Y,1)',turank(1));
[U{2},~,~]=svds(Unfold(Y,2)*Unfold(Y,2)',turank(2));
Gu=tucker_als(tensor(imresize(X,ratio)),turank);
% [U{3},~,~]=svds(Unfold(X,3)*Unfold(X,3)',turank(3));
U{3}=Gu.U{3};
Uaux=U;
%G=GIni(SRI,X,Y,P,U,eta,phi,rho,alpha,beta,ksi,turank,shape_re,ss,IniLoop,InLoop);
G=zeros(turank);
psnr(double(ttm(tensor(G),U)),SRI)
LS=cell(2,K);
MN=cell(2,K);
for k=1:K
    LS{1,k}=CirUnfold(reshape(G,shape_re),k,ss);LS{2,k}=CirUnfold(reshape(G,shape_re),k,ss);
    MN{1,k}=zeros(size(LS{1,k}));MN{2,k}=zeros(size(LS{2,k}));
end

Px=zeros(size(X));Py=zeros(size(Y));
Fu=cell(1,3);
for i=1:3
    Fu{i}=zeros(size(U{i}));
end
GLS=cell(2,K);

rhomax=1e10;nu=1;psi=1e-2;ULoop=10;
ps=[];
%% Main algorithm
for loop=1:MaxLoop
    %%Update G
    disp('Update G')
    for k=1:K
    % GLS{1,k}=reshape(CirFold(LS{1,k}-MN{1,k}/rho(2),k,ss,shape_re),turank);
    GLS{2,k}=reshape(CirFold(LS{2,k}-MN{2,k}/rho(2),k,ss,shape_re),turank);
    end
    Gpre=G;
    G = ADMM_G(X+Px/rho(1),Y+Py/rho(1),G,U,Uaux,P,GLS,rho,ksi,InLoop);
    %%Update U&Uaux
    disp('Update U&Uaux')
    for i=1:3
        U{i}=ADMM_U(X+Px/rho(1),Y+Py/rho(1),G,U,P,psi,ULoop,i);
    end
    Uaux=U;
    
% % % % % % % % %     for i=1:3
% % % % % % % % %         if i==3
% % % % % % % % %             Uaux
% % % % % % % % %             [E,F,B,Tau] = CreateCGSys(Y+Py/rho(1),G,U,Uaux,P,U{i}+Fu{i}/rho(1),1,i);
% % % % % % % % %             Uaux{i} = CGra(E,F,Tau,Uaux{i},B);
% % % % % % % % %             U
% % % % % % % % %             Raux=0;
% % % % % % % % %             for r=1:R
% % % % % % % % %                 Raux=Raux+double(ttm(tensor(G),{P{r,1}*Uaux{1},P{r,2}*Uaux{2}},[1,2]));
% % % % % % % % %             end
% % % % % % % % %             [J,~,Q]=svd(Unfold(Raux,i)*Unfold(X+Px/rho(1),i)'+(Uaux{i}-Fu{i}/rho(1))');
% % % % % % % % %             U{i}=Q(:,1:size(U{i},2))*J';
% % % % % % % % %         else
% % % % % % % % %             Uaux
% % % % % % % % %             [E,F,B,Tau] = CreateCGSys(X+Px/rho(1),G,U,Uaux,P,U{i}+Fu{i}/rho(1),1,i);
% % % % % % % % %             Uaux{i} = CGra(E,F,Tau,Uaux{i},B);
% % % % % % % % %             U
% % % % % % % % %             [J,~,Q]=svd(Unfold(double(ttm(tensor(G),{U{3-i},P{1,3}*Uaux{3}},[3-i,3])),i) ...
% % % % % % % % %             *Unfold(Y+Py/rho(1),i)'+(Uaux{i}-Fu{i}/rho(1))');
% % % % % % % % %             U{i}=Q(:,1:size(U{i},2))*J';
% % % % % % % % %         end
% % % % % % % % %     end
    %%Update L,S
    disp('Update L,S')
    for k=1:K
        %L
% % % % % %         disp('Update L')
% % % % % %         [J,Sig,Q]=svd(CirUnfold(reshape(G,shape_re),k,ss)+MN{1,k}/rho(2));
% % % % % %         Sig_=LapSparse(Sig,eta*alpha(k)/rho(2),1e-3,1e-7);
% % % % % %         LS{1,k}=J*Sig_*Q';
        %S
        disp('Update S')
        LS{2,k}=LapSparse(CirUnfold(reshape(G,shape_re),k,ss)+MN{2,k}/rho(2),phi*beta(k)/rho(2),1e1,1e-7);
    end
    %Update Lagrarian Variables
    disp('Update Lagrarian Variables')
    HSIes=0;
    for r=1:R
        HSIes=HSIes+double(ttm(tensor(G),{P{r,1}*Uaux{1},P{r,2}*Uaux{2},U{3}}));
    end
    Px=Px+rho(1)*(X-HSIes);
    Py=Py+rho(1)*(Y-double(ttm(tensor(G),{U{1},U{2},P{1,3}*Uaux{3}})));
    for k=1:K
% % % % % %         MN{1,k}=MN{1,k}+rho(2)*(CirUnfold(reshape(G,shape_re),k,ss)-LS{1,k});
        MN{2,k}=MN{2,k}+rho(2)*(CirUnfold(reshape(G,shape_re),k,ss)-LS{2,k});
    end
% % % % % % % %     for i=1:3
% % % % % % % %         Fu{i}=Fu{i}+rho(1)*(U{i}-Uaux{i});
% % % % % % % %     end
    
    %Update rho
    rho=min(rhomax,nu*rho);
    %Stride
    bK=cell(1,K);
    for k=1:K
        bK{k}=norm(CirUnfold(reshape(G,shape_re),k,ss)-LS{2,k},'fro')/norm(CirUnfold(reshape(G,shape_re),k,ss),'fro')
    end
    bI=cell(1,3)
    for i=1:3
        bI{i}=norm(U{i}-Uaux{i},'fro')/norm(U{i},'fro')
    end
    St1=norm(Unfold(G-Gpre,2),'fro')/norm(Unfold(G,2),'fro')
    b1=norm(Unfold(X-FormHSI({G},U,Uaux,P),2),'fro')/norm(Unfold(X,2),'fro')
    b2=norm(Unfold(Y-double(ttm(tensor(G),{U{1},U{2},P{1,3}*Uaux{3}})),2),'fro')/norm(Unfold(Y,2),'fro')
    
    
    Z=double(ttm(tensor(G),U));
    psnr(Z,SRI)
    ps=[ps,psnr(Z,SRI)];
    
end
plot(ps)
end

