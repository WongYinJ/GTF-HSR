function [E,F,B,Tau] = CreateCGSys_v2(Tx,Ty,G,Gr,U,P,i)
%CREATECGSYS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
R=size(P,1);
B=0;
if i==3
    E=cell(1,2);F=cell(1,2);
    Uaux=U;Uaux{3}=eye(size(U{3},2));
    Gx=Unfold(FormHSI(Gr,Uaux,U,P),i);
    Gy=Unfold(double(ttm(tensor(G),{U{1},U{2}},[1,2])),i);
    B=P{1,3}'*Unfold(Ty,3)*Gy'+Unfold(Tx,3)*Gx';
    E{1}=P{1,3}'*P{1,3};F{1}=Gy*Gy';
    E{end}=eye(size(U{3},1));F{end}=Gx*Gx';
    Tau=[1,1];
else
    FoldG=cell(1,R+1);
    for r=1:R
        FoldG{r}=Unfold(double(ttm(tensor(Gr{r}),{P{r,3-i}*U{3-i},U{3}},[3-i,3])),i);
        B=B+P{r,i}'*Unfold(Tx,i)*FoldG{r}';
    end
    FoldG{R+1}=Unfold(double(ttm(tensor(G),{U{3-i},P{1,3}*U{3}},[3-i,3])),i);
    B=B+Unfold(Ty,i)*FoldG{R+1}';
    E=cell(1,R^2+1);F=cell(1,R^2+1);
    k=1;
    for r1=1:R
        for r2=1:R
            E{k}=P{r1,i}'*P{r2,i};F{k}=FoldG{r2}*FoldG{r1}';
            k=k+1;
        end
    end
    E{end}=eye(size(U{i},1));F{end}=FoldG{R+1}*FoldG{R+1}';
    Tau=ones(1,k);
end
end

