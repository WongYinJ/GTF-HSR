function [Z,ob] = ReTF_v2_1(SRI,X,Y,P,lambda,rho,turank,shape_re,MaxLoop,InLoop)
%RETF �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% X:HSI; Y: MSI; P:R��3 cell containing degradation matrices
% eta: low-rank parameter; phi: sparse parameter; rho: optimization penalty
%%%Preparation
[m,n,S]=size(X);[M,N,s]=size(Y);
ratio=M/m;
R=size(P,1);
K=length(shape_re);

% % Gu=tucker_als(tensor(imresize(X,ratio)),turank);
% % G=double(Gu.core);
% % U=Gu.U';Uaux=Gu.U';
% % psnr(double(ttm(tensor(G),U)),SRI)
U=cell(1,3);
[U{1},~,~]=svds(Unfold(Y,1)*Unfold(Y,1)',turank(1));
[U{2},~,~]=svds(Unfold(Y,2)*Unfold(Y,2)',turank(2));
U{3}=vca(Unfold(X,3),'Endmembers',turank(3));
% % % % % % % % % % % % % % % % % % % % % % % % % Gu=tucker_als(tensor(imresize(X,ratio)),turank);
% % % % % % % % % % % % % % % % % % % % % % % % % % [U{3},~,~]=svds(Unfold(X,3)*Unfold(X,3)',turank(3));
% % % % % % % % % % % % % % % % % % % % % % % % % U{3}=Gu.U{3};
G=zeros(turank);
psnr(double(ttm(tensor(G),U)),SRI)

ps=[];
%% Main algorithm
for loop=1:MaxLoop
    
   %%%Update G
   [G,Gr]=GIni_v2(SRI,X,Y,P,G,U,lambda,rho,turank,shape_re,70);
   
   
   %%%Update U
   for inLoop=1:InLoop
   for n=1:3
       Ob1=(norm(Unfold(X-FormHSI(Gr,U,U,P),n),'fro'))^2+...
           (norm(Unfold(Y-double(ttm(tensor(G),{U{1},U{2},P{1,3}*U{3}})),n),'fro'))^2
       [E,F,B,Tau] = CreateCGSys_v2(X,Y,G,Gr,U,P,n);
       U{n} = CGra(E,F,Tau,U{n},B);
       Ob1=(norm(Unfold(X-FormHSI(Gr,U,U,P),n),'fro'))^2+...
           (norm(Unfold(Y-double(ttm(tensor(G),{U{1},U{2},P{1,3}*U{3}})),n),'fro'))^2
   end
   end
    
    
    Z=double(ttm(tensor(G),U));
    psnr(Z,SRI)
    ps=[ps,psnr(Z,SRI)];
    
end
plot(ps)
end

